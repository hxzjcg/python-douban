import pymysql


# 第一层写入数据
def   InsertIdMysql(list):
    db = pymysql.connect(
        host="127.0.0.1",
        port=3306,
        user="root",
        passwd="193750",
        db="moive",
        charset='utf8'
    )
    # 要写入的数据库名称
    table = 'information'
    # 要写入的数据库列表
    field_array = ['directors','rate','cover_x','star','name','url','casts','cover','id','cover_y']
    # 使用定位将数据并行输入
    SQL = f"INSERT INTO {table}({','.join(field_array)}) VALUES ({','.join(['%s'] * len(field_array))})"
    # 将要写入的数据先行准备好
    values = []
    # 使用cursor方法创建一个游标
    cursor = db.cursor()
    if cursor:
        try:
            # 将要写入的数据填充
            val = [list[0],list[1],list[2],list[3],list[4],list[5],list[6],list[7],list[8],list[9]]
            # 依次写入
            values.append(tuple(val))
            # 执行
            cursor.executemany(SQL, values)
            db.commit()
        except Exception as e:
            None
    else:
        print("连接失败")
    db.close()


# 添加第二层信息
def the_next_information(which,value,isbn):
    db = pymysql.connect(
        host="127.0.0.1",
        port=3306,
        user="root",
        passwd="193750",
        db="moive",
        charset='utf8'
    )
    # 要修改的数据库名称
    table = 'information'
    # 使用定位将数据并行输入
    if which==1:
        SQL = f"update information set 电影类型 = %s where id = %s"
    elif which==2:
        SQL = f"update information set 上映时间 = %s where id = %s"
    elif which==3:
        SQL = f"update information set 电影时长 = %s where id = %s"
    elif which==4:
        SQL = f"update information set 内容简介 = %s where id = %s"
    elif which==5:
        SQL = f"update information set `5星占比` = %s where id = %s"
    elif which==6:
        SQL = f"update information set `4星占比` = %s where id = %s"
    elif which==7:
        SQL = f"update information set `3星占比` = %s where id = %s"
    elif which==8:
        SQL = f"update information set `2星占比` = %s where id = %s"
    elif which==9:
        SQL = f"update information set `1星占比` = %s where id= %s"
    # 将要写入的数据先行准备好
    values = []
    # 使用cursor方法创建一个游标
    cursor = db.cursor()
    if cursor:
        try:
            # 将要写入的数据填充
            val = [value,isbn]
            # 依次写入
            values.append(tuple(val))
            # 执行
            cursor.executemany(SQL, values)
            db.commit()
        except Exception as e:
            None
    else:
        print("连接失败")
    db.close()




# 添加第三层信息
def the_last_information(which,value,isbn):
    db = pymysql.connect(
        host="127.0.0.1",
        port=3306,
        user="root",
        passwd="193750",
        db="moive",
        charset='utf8'
    )
    # 要修改的数据库名称
    table = 'information'
    # 使用定位将数据并行输入
    if which==1:
        SQL = f"update information set 影评1 = %s where id = %s"
    elif which==2:
        SQL = f"update information set 影评2 = %s where id = %s"
    elif which==3:
        SQL = f"update information set 影评3 = %s where id = %s"
    elif which==4:
        SQL = f"update information set 影评4 = %s where id = %s"
    elif which==5:
        SQL = f"update information set 影评5 = %s where id = %s"
    elif which==6:
        SQL = f"update information set 影评6 = %s where id = %s"
    elif which==7:
        SQL = f"update information set 影评7 = %s where id = %s"
    elif which==8:
        SQL = f"update information set 影评8 = %s where id = %s"
    elif which==9:
        SQL = f"update information set 影评9 = %s where id = %s"
    elif which == 10:
        SQL = f"update information set 影评10 = %s where id = %s"
    elif which==11:
        SQL = f"update information set 影评11 = %s where id = %s"
    elif which==12:
        SQL = f"update information set 影评12 = %s where id = %s"
    elif which==13:
        SQL = f"update information set 影评13 = %s where id = %s"
    elif which==14:
        SQL = f"update information set 影评14 = %s where id = %s"
    elif which==15:
        SQL = f"update information set 影评15 = %s where id = %s"
    elif which==16:
        SQL = f"update information set 影评16 = %s where id = %s"
    elif which==17:
        SQL = f"update information set 影评17 = %s where id = %s"
    elif which==18:
        SQL = f"update information set 影评18 = %s where id = %s"
    elif which == 19:
        SQL = f"update information set 影评19 = %s where id = %s"
    elif which == 20:
        SQL = f"update information set 影评20 = %s where id = %s"

    # 将要写入的数据先行准备好
    values = []
    # 使用cursor方法创建一个游标
    cursor = db.cursor()
    if cursor:
        try:
            # 将要写入的数据填充
            val = [value,isbn]
            # 依次写入
            values.append(tuple(val))
            # 执行
            cursor.executemany(SQL, values)
            db.commit()
        except Exception as e:
            None
    else:
        print("连接失败")
    db.close()