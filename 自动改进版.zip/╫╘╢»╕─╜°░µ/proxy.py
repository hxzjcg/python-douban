import time

from fake_user_agent import user_agent


def header():
    ua = user_agent()  # 实例化
    # 请求头就可以写成
    headers = {"User-Agent": ua}
    return headers

"""
使用requests请求隧道服务器
请求http和https网页均适用
"""

import requests
def proxies():
    # 隧道域名:端口号
    time.sleep(1)
    tunnel = "j735.kdltps.com:15818"

    # 用户名密码方式
    username = "t17998224481352"
    password = "f5w1zvpa"
    proxies = {
        "https": "http://%(user)s:%(pwd)s@%(proxy)s/" % {"user": username, "pwd": password, "proxy": tunnel}
    }

    # 白名单方式（需提前设置白名单）
    # proxies = {
    #     "http": "http://%(proxy)s/" % {"proxy": tunnel},
    #     "https": "http://%(proxy)s/" % {"proxy": tunnel}
    # }

    return proxies

