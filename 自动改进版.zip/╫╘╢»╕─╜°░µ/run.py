import time
from multiprocessing.dummy import Pool as ThreadPool
import first_layer_of_url_acquisition
import get_frist

def main():
    start = time.time()
    pool = ThreadPool(16)
    print(len(first_layer_of_url_acquisition.all_url()))
    pool.map(get_frist.the_frist_information1, first_layer_of_url_acquisition.all_url())
    end = time.time()
    lastT = int(end - start)
    print('总共耗时{}s'.format(lastT))


if __name__ == '__main__':
    main()