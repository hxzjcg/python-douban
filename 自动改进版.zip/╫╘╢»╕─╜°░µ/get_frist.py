import time
import requests
import mysql
import proxy
import get_second

def xieru_excpt(url):
    file = open("url", 'a')
    s = str(url) + '\n'
    file.write(s)
    file.close()

# 获取链接中的json信息
def the_frist_information1(url):
    try:
        html = requests.get(url=url, headers=proxy.header(),proxies=proxy.proxies())
        html_json = html.json()
        html.close()
        # 下一级的url数据
        url_list=[]
        list_moive_information = []

        # 获取第一层的主要数据
        main_infomation = html_json.get('data')
        # 正常情况下这个是20的长度，如果为0就可以直接跳过了
        lenght=len(main_infomation)
        if lenght==0:
            return
        else:
            for list in main_infomation:
                directors = list.get('directors')  # 列表
                try:
                    list_moive_information.append(str(directors[0]))
                except IndexError:
                    list_moive_information.append("无")
                rate = list.get('rate')
                list_moive_information.append(rate)
                cover_x = list.get('cover_x')
                list_moive_information.append(cover_x)
                star = list.get('star')
                list_moive_information.append(star)
                title = list.get('title')
                list_moive_information.append(title)
                url = list.get('url')
                url_list.append(url)
                list_moive_information.append(url)
                casts = list.get('casts')  # 列表
                list_moive_information.append(str(casts))
                cover = list.get('cover')
                list_moive_information.append(cover)
                id = list.get('id')
                list_moive_information.append(id)
                cover_y = list.get('cover_y')
                list_moive_information.append(cover_y)
                mysql.InsertIdMysql(list_moive_information)
            get_second.the_second_information(url_list)
            print('ok')
        time.sleep(1)
    except Exception as e:
        xieru_excpt(url)
        print(e)

