import tqdm
from requests.packages.urllib3.packages.six.moves.urllib.parse import urlencode


def all_url():
    # 创建接受所有初始链接数据的列表 作为多线程的基础链接
    all_list = []
    formdata = {
        'sort': 'T',
        'range': "m,n",
        'tags': '电影',
        'start': '0'
    }
    scores = ['9,10', '8,9', '7.6, 8', '7,3,7.6', '7,7.3', '6.7, 7', '6.5, 6.7', '6,6.5', '5,6', '4,5', '3,4', '2,3']
    print("初始化中。。。。")
    for score in tqdm.tqdm(scores, "第一层链接"):
        formdata['range'] = score
        for i in range(0, 9980, 20):
            start = str(i)
            formdata['range'] = score
            formdata['start'] = start
            url = 'http://movie.douban.com/j/new_search_subjects?' + urlencode(formdata)
            all_list.append(url)
    return all_list


