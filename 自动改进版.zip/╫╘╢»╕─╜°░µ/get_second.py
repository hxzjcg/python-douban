import re
import requests
from lxml import etree
import proxy
import mysql


def neirong(list):
    text = ''
    if len(list) > 0:
        for index in range(len(list)):
            if index == len(list) - 1:
                text = text + str(list[index]).replace('\u3000', '').replace(' ', '').replace('\n', '')
            else:
                text = text + str(list[index]).replace('\u3000', '').replace(' ', '').replace('\n', '') + '/'

    return text


def the_second_information(url_list):
    for x in url_list:
        the_second_information_list = []
        url = str(x)
        # 定制请求头
        request = requests.get(url=url, headers=proxy.header(),proxies=proxy.proxies())
        # 发送请求访问服务器，返回响应对象
        # 解码响应对象，得到页面源码
        content = request.text
        content.encode('utf-8')
        # 解析服务器响应的文件
        Selector = etree.HTML(content)
        # 编写xpath路径，获取想要的数据,xpath的返回值是列表类型,对列表内容进行提取即可
        try:

            # type代表电影类型
            # times代表上映时间
            # long代表电影时长
            # book代表内容简介
            # start代表星级占比

            type = Selector.xpath('//span[@property="v:genre"]/text()')
            the_second_information_list.append(neirong(type))
            times = Selector.xpath('//span[@property="v:initialReleaseDate"]/text()')
            the_second_information_list.append(neirong(times))
            long = Selector.xpath('//span[@property="v:runtime"]/text()')
            the_second_information_list.append(neirong(long))
            book = Selector.xpath('//span[@property="v:summary"]/text()')
            the_second_information_list.append(neirong(book))
            start = Selector.xpath('//span[@class="rating_per"]/text()')
            for stars in start:
                stars = str(stars)
                the_second_information_list.append(stars)
            re_id = 'https://movie.douban.com/subject/(.*?)/'
            id = re.findall(re_id, url, re.A)
            id = int(id[0])
            # 存储在数据库
            index = 1
            for y in the_second_information_list:
                mysql.the_next_information(index, y, id)
                index += 1
        except Exception as e:
            print(e)
            print('电影爬虫失败，链接为' + url)
